import kollektiv5gui

if __name__ == '__main__':
    kollektiv5gui.main()
